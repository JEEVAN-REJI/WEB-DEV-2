package com.mutualbooks.controller;

import java.io.IOException;
import java.util.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.mutualbooks.app.*;

/**
 * Servlet implementation class BooksServlet
 */
@WebServlet("/BooksServlet")
public class BooksServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BooksServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		String strRequestID;
		strRequestID = request.getParameter("reqID");
		System.out.println(strRequestID);
		int bookID=0;
		if (strRequestID.equals("publish")){
			bookID = doPublish(request, response);
			System.out.println("requesId bookID"+bookID);
		
		if (bookID != 0)
		{
			request.setAttribute("result", "new book published");
		}
		else
		{
			request.setAttribute("result","failed to publish the book");
		}
		
		request.getRequestDispatcher("registeroutput.jsp").forward(request,response);
	}
	if (strRequestID.equals("search")){
		Vector srResults = doSearch(request, response);
		request.setAttribute("searchresult", srResults);
		request.getRequestDispatcher("searchresult.jsp").forward(request,response);
     }
	if (strRequestID.equals("requestissue")){
		int reqStatus = doRequestIssue(request, response);
		if(reqStatus==1) {
			request.setAttribute("error","Success");
			request.getRequestDispatcher("searchbook.jsp").forward(request,response);
     }
		else if(reqStatus==2) {
			request.setAttribute("error", "No Balance");
			request.getRequestDispatcher("searchbook.jsp").forward(request, response);
		}
		else {
			request.setAttribute("error", "Not Available");
			request.getRequestDispatcher("searchbook.jsp").forward(request, response);
		}
	}
	
	if( strRequestID.equals("recharge")) {
		boolean rechargeStatus =  doRecharge(request,response);
		if(rechargeStatus) {
			request.setAttribute("error", "Succesfully recharged");
			request.getRequestDispatcher("rechrgwlt.jsp").forward(request,response);
     }
		else {
			request.setAttribute("error", "Book Not Available");
			request.getRequestDispatcher("rechrgwlt.jsp").forward(request, response);
		}
	}
	
	if( strRequestID.equals("delete")) {
		Vector dlResults = doRemove(request, response);
		request.setAttribute("deleteresult", dlResults);
		request.getRequestDispatcher("deleteresult.jsp").forward(request,response);
	}
	
	if(strRequestID.equals("deletebook")) {
		int reqStatus = doDeleteIssue(request, response);
		if(reqStatus==1) {
			request.setAttribute("error","Success");
			request.getRequestDispatcher("deletebook.jsp").forward(request,response);
     }
		else {
			request.setAttribute("error", "Fail");
			request.getRequestDispatcher("deletebook.jsp").forward(request, response);
		}
	}
	
	if(strRequestID.equals("issuebook")) {
		System.out.println("ENTERED THE ISSUE BOOK!");
		HashMap loginObject = doIssue(request, response);
		if (loginObject!=null)
		{
			if(loginObject.get("error")==null)
				request.setAttribute("result","success");
			request.setAttribute("dshobject",loginObject);
			request.getRequestDispatcher("dashboard.jsp").forward(request,response);
		}
		else
		{
			request.setAttribute("result","user login not successful");
			request.getRequestDispatcher("index.jsp").forward(request,response);
		}
	}
	
}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	private int doPublish(HttpServletRequest request, HttpServletResponse response) {
		System.out.println((String)request.getSession().getAttribute("loginDispalyName"));
		System.out.println("inside doPublish");
		Book newBook = new Book();
		newBook.setTitle(request.getParameter("title"));
		newBook.setAuthors(request.getParameter("author1"),request.getParameter("author2"),request.getParameter("author3"),request.getParameter("author4"));
		newBook.setPublisher(request.getParameter("publisher"));
		newBook.setEdition(request.getParameter("edition"));
		newBook.setYear(request.getParameter("year"));
		newBook.setUserID((int)request.getSession().getAttribute("loginUserID"));
		//User Manager 
		BookManager bookMgr = new BookManager();
		int flag;
		flag = bookMgr.publishBook(newBook);
		return flag;
	}
	
private Vector doSearch(HttpServletRequest request, HttpServletResponse response) {
		
		System.out.println("inside doSearch");
		BookManager bookMgr = new BookManager();
		Vector srchList;
		srchList = bookMgr.searchBook(request.getParameter("title"),request.getParameter("author"),(int)request.getSession().getAttribute("loginUserID"));
		return srchList;
	}

private int doRequestIssue(HttpServletRequest request, HttpServletResponse response) {
	System.out.println("inside doRequestIssue");
	System.out.println(request.getParameter("bookselect"));
	BookManager bookMgr = new BookManager();
	int issueStatus = bookMgr.requestIssue((int)request.getSession().getAttribute("loginUserID"),request.getParameter("bookselect"));
	return issueStatus;
}

private int doDeleteIssue(HttpServletRequest request, HttpServletResponse response) {
	System.out.println("inside doDeleteIssue");
	System.out.println(request.getParameter("deleteselect"));
	BookManager bookMgr = new BookManager();
	int issueStatus = bookMgr.deleteBook((int)request.getSession().getAttribute("loginUserID"),request.getParameter("deleteselect"));
	return issueStatus;
}

private boolean doRecharge(HttpServletRequest request, HttpServletResponse response) {
	System.out.println("inside doRecharge");
	WalletManager  wltMgr = new WalletManager();
	boolean rechargeStatus = wltMgr.requestRecharge((int)request.getSession().getAttribute("loginUserID"),request.getParameter("amount"));
	return rechargeStatus;
}

private Vector doRemove(HttpServletRequest request, HttpServletResponse response) {
	
	System.out.println("inside doRemove");
	BookManager bookMgr = new BookManager();
	Vector myList;
	myList = bookMgr.myBooks((int)request.getSession().getAttribute("loginUserID"));
	return myList;
}

private HashMap doIssue(HttpServletRequest request, HttpServletResponse response) {
	System.out.println("inside doIssue");
	BookManager bkMgr = new BookManager();
	String reqParam = request.getParameter("bookselect");
	StringTokenizer strtoken = new StringTokenizer(reqParam,"#");
	String userID=null;
	String bookID=null;
	int i=0;
	while(strtoken.hasMoreTokens()) {
		if(i==0)
		bookID = strtoken.nextToken();
		else
		userID = strtoken.nextToken();
		i++;
	}
	System.out.println(userID);
	System.out.println(bookID);
	HashMap rechargeStatus = bkMgr.issueBook(userID,bookID);
	return rechargeStatus;
}


}
