package com.mutualbooks.controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.HashMap;
import com.mutualbooks.app.*;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public LoginServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//sponse.getWriter().append("Served at: ").append(request.getContextPath());
		String strRequestID;
		strRequestID = request.getParameter("reqID");
		if (strRequestID.equals("register")){
			int userStatus = doRegister(request, response);
			System.out.println("requesId userstatus"+userStatus);
			if (userStatus != 0)
			{
				request.setAttribute("result", "user created successfully");
				request.getRequestDispatcher("index.jsp").forward(request,response);
			}
			else
			{
				request.setAttribute("result","failed to created user");
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}
			
		}
		if (strRequestID.equals("login")){
			
			User loginObject = userLogin(request, response);
			if (loginObject!=null)
			{
				request.getSession().setAttribute("loginUserID", loginObject.getUserID());
				request.getSession().setAttribute("loginDisplayName", loginObject.getDisplayName());
				request.getSession().setAttribute("loginIsAdmin", loginObject.getIsAdmin());
				HashMap myResults = getDashboard(loginObject.getUserID());
				request.setAttribute("dshobject", myResults);
				request.getRequestDispatcher("dashboard.jsp").forward(request,response);
			}
			else
			{
				request.setAttribute("result","user login not successful");
				request.getRequestDispatcher("index.jsp").forward(request,response);
			}
		}
		
		if(strRequestID.equals("pwdchange")) {
			boolean change = doPasswordChange(request,response);
			if(change==true) {
				request.setAttribute("result","pwd change success!");
				request.getRequestDispatcher("dashboard.jsp").forward(request,response);
			}
			else {
				request.setAttribute("error","pwd change failed!");
				request.getRequestDispatcher("chgpwd.jsp").forward(request,response);
			}
		}
		
		if(strRequestID.equals("manage")) {
			
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	private int doRegister(HttpServletRequest request, HttpServletResponse response)
	{
	    System.out.println("inside doRegiser");
		User newUser = new User();
		newUser.setLoginID(request.getParameter("loginID"));
		newUser.setPassword(request.getParameter("pwd"));
		newUser.setDisplayName(request.getParameter("displayname"));
		newUser.setEmail(request.getParameter("emailid"));
		newUser.setAddress(request.getParameter("address"));
		newUser.setPhoneNumber(request.getParameter("phone"));
		//User Manager 
		UserManager userMgr = new UserManager();
		int flag;
		flag = userMgr.doRegister(newUser);
		if(flag!=0) {
		Wallet newWallet = new Wallet();
		newWallet.setUserID(flag);
		newWallet.setBalance(0);
		WalletManager wltMgr = new WalletManager();
		flag = wltMgr.doWltRegister(newWallet);
		}
		return flag;
	}
	
	private User userLogin(HttpServletRequest request, HttpServletResponse response) 
	{
		
		 System.out.println("inside user Login");
		 UserManager userMgr = new UserManager();
		 User status = userMgr.doLogin(request.getParameter("loginID"),request.getParameter("pwd"));
		 return status;
	}

	private boolean doPasswordChange(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("inside password change");
		UserManager userMgr = new UserManager();
		System.out.println((String)request.getAttribute("pwd"));
		boolean status = userMgr.doPwdChange((int)request.getSession().getAttribute("loginUserID"),request.getParameter("pwd"));
		return status;
	}
private HashMap getDashboard(int iUserID) {
		
		BookManager bookMgr = new BookManager();
		HashMap lstDshObjects = bookMgr.getDashboard(iUserID);
		return lstDshObjects;
		
		}
}
