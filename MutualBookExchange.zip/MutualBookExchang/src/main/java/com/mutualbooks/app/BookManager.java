package com.mutualbooks.app;

import java.sql.*;
import java.util.*;
public class BookManager {

	
	public int publishBook(Book newBook) {
		 ArrayList lstauthor = newBook.getAuthors();
		 Iterator lstit = lstauthor.listIterator();
		 String strauthor ="";
		 while(lstit.hasNext()) {
			 strauthor += ",'"+lstit.next()+"'";
		 }
		 System.out.println(strauthor);
		 Connection dbcon = getDBConnection();
		 try {
			 Statement stmt = dbcon.createStatement();
			 String strsql="select max(BookID) from books";
			 ResultSet rs = stmt.executeQuery(strsql);
			 int id = 0;
			 while(rs.next()) {
				 id = rs.getInt(1);
				 System.out.println(id);
			 }
			 id++;
			 newBook.setBookID(id);
			 strsql = "insert into books values("+id+",'"+newBook.getTitle()+"'"+strauthor+",'"+newBook.getPublisher()+"',"+newBook.getYear()+","+newBook.getUserID()+")";
			System.out.println(strsql);
			 stmt.executeUpdate(strsql);
			 
			 dbcon.close();
			 return 1;
		 }catch(Exception e){System.out.println(e); 
		 return 0;
		 }
		 
	}
public Vector searchBook (String bkTitle, String bkAuthor,int bkUserID) {
		
		Vector results = new Vector();
		 Connection dbcon = getDBConnection();
		 try {
			 Statement stmt = dbcon.createStatement();
			 String strsql= "";
			 if(bkTitle.equals("") && !bkAuthor.equals("")) {
				 strsql="select * from books where (UserID <>"+bkUserID+") and ((Author1 ='%"+bkAuthor+"%') or (Author2='%"+bkAuthor+"%') or (Author3='%"+bkAuthor+"%') or (Author4='%"+bkAuthor+"%'))";
			 }
			 else if(bkAuthor.equals("") && !bkTitle.equals("")) {
				  strsql="select DisplayTitle,BookID from books  where DisplayTitle like '%"+bkTitle+"%'"+"and UserID not like "+bkUserID;
			 }
			 else {	 
				 strsql="select DisplayTitle,BookID from books where (UserID <>"+bkUserID+")";
			 }
			 System.out.println(strsql);
			 ResultSet rs = stmt.executeQuery(strsql);
			 int id = 0;
			 while(rs.next()) {
				 Book srchBook = new Book();
				  srchBook.setTitle(rs.getString(1));
				  srchBook.setBookID(rs.getInt(2));
				  results.add(srchBook);
			 } 
			 dbcon.close();
			 return results;
		 }catch(Exception e){System.out.println(e); 
		 return null;
		 }

	}

public Vector myBooks(int userID) {
	
	Vector results = new Vector();
	 Connection dbcon = getDBConnection();
	 try {
		 Statement stmt = dbcon.createStatement();
		 String strsql= "";
	
		 strsql="select DisplayTitle,BookID from books where (UserID ="+userID+")";
		 System.out.println(strsql);
		 ResultSet rs = stmt.executeQuery(strsql);
		 int id = 0;
		 while(rs.next()) {
			 Book srchBook = new Book();
			  srchBook.setTitle(rs.getString(1));
			  srchBook.setBookID(rs.getInt(2));
			  results.add(srchBook);
		 } 
		 dbcon.close();
		 return results;
	 }catch(Exception e){System.out.println(e); 
	 return null;
	 }

}
public int requestIssue(int userID, String bookID) {
	Connection dbcon = getDBConnection();
	int ret = 1;
	int f = userID;
	 try {
		 Statement stmt = dbcon.createStatement();
		 String strsql="select status from book_issue where BookID ="+bookID;
		 System.out.println(strsql);
		 ResultSet rs = stmt.executeQuery(strsql);
		 String status=null;
		 while(rs.next()) {
			 status = rs.getString(1);
			 System.out.println(status);
			 if(status.equals("returned")|| status.equals("requested")) { //only if issued i can't place a request
				 ret = 1;
			 }
			 else {
				 ret = 0;
			 }
		 }
		 if(ret==1) {
			 System.out.println("Entered here!");
			 strsql = "select Balance from wallet where UserID="+userID;
			 ResultSet rs2 = stmt.executeQuery(strsql);
			 int curr_balance = 0;
			 while(rs2.next()) {
				 curr_balance = rs2.getInt(1);
				 if(curr_balance<15) {
					 ret = 2;
				 }
			 }
			 if(ret==1) {
			
			 curr_balance = curr_balance-15;
			 strsql = "update wallet set Balance="+curr_balance+" where UserID ="+userID+";";
			 stmt.executeUpdate(strsql);
			 strsql = "insert into book_issue(RequesterID,BookID,RequestDate,Status) values("+userID+","+bookID+", (select CURRENT_DATE()),'requested')";
			 System.out.println(strsql);
			 stmt.executeUpdate(strsql);
			 }
			 
		 }
		 
		 dbcon.close();
		 return ret;
	 }catch(Exception e){System.out.println(e); 
	 return 0;
	 }
}

public int deleteBook(int userID, String bookID) {
	Connection dbcon = getDBConnection();
	int ret = 1;
	int f = userID;
	 try {
		 Statement stmt = dbcon.createStatement();
		 String strsql="select status from book_issue where BookID ="+Integer.parseInt(bookID);
		 System.out.println(strsql);
		 ResultSet rs = stmt.executeQuery(strsql);
		 String status=null;
		 while(rs.next()) {
			 status = rs.getString(1);
			 System.out.println(status);
			 if(status.equals("returned")|| status.equals("requested")) { //only if issued i can't place a request
				 ret = 1;
			 }
			 else {
				 ret = 0;
				 break;
			 }
		 }
		 if(ret==1) {
			 System.out.println("Entered here!");
			 //refund the money
			 strsql = "select RequesterID from book_issue  where ((BookID="+bookID+") and (Status='requested'))";
			 System.out.println(strsql);
			 ResultSet rs2 = stmt.executeQuery(strsql);
			 Vector v = new Vector();
			 int c = 0;
			 while(rs2.next()) {
				  c= rs2.getInt(1);
				  v.add(c);
			 }
			 
			 ResultSet rs3=null;
			 for(int i=0;i<v.size();i++) {
				 strsql = "select Balance from wallet where UserID="+v.get(i);
				 rs3 = stmt.executeQuery(strsql);
				int balance=0;
				while(rs3.next()) {
					balance= rs3.getInt(1);
					balance+=15;
				}
				System.out.println(balance);
				strsql = "update wallet set Balance="+balance+" where UserID="+v.get(i);
				stmt.executeUpdate(strsql);
			 }
			 
			 strsql = "delete from book_issue where (BookID="+bookID+")";
			 System.out.println("reached here!");
			 stmt.executeUpdate(strsql);
			 
			 strsql = "delete from books where (BookID="+bookID+")";
			 stmt.executeUpdate(strsql);
			 
		 }
		 
		 dbcon.close();
		 return ret;
	 }catch(Exception e){System.out.println(e); 
	 return 0;
	 }
}

public HashMap getDashboard(int userID) {
	
	HashMap results = new HashMap();
	
	Vector pendingRequests = new Vector();
	
	Vector myRequests = new Vector();

	 Connection dbcon = getDBConnection();
	 try {
		 Statement stmt = dbcon.createStatement();
		 String strsql="select books.DisplayTitle,user_details.DisplayName, book_issue.RequestDate,books.BookID,book_issue.RequesterID from book_issue inner join books on book_issue.BookID=books.BookID\r\n"
		 		+ "inner join user_details on book_issue.RequesterID=user_details.UserID \r\n"
		 		+ "where books.UserID="+userID+" and book_issue.Status='requested';";
		 ResultSet rs = stmt.executeQuery(strsql);
		 while(rs.next()) {
			 HashMap bookObj = new HashMap();
			 bookObj.put("Book_Name", rs.getString(1));
			 bookObj.put("Requester_Name",rs.getString(2));
			 bookObj.put("Request_Date",rs.getString(3));
			 bookObj.put("Book_ID",rs.getString(4));
			 bookObj.put("Requester_ID",rs.getString(5));
			 System.out.println(bookObj);
			 pendingRequests.add(bookObj);
		 }
		 
		 
		 strsql = "select books.BookID, books.DisplayTitle,book_issue.RequestDate,book_issue.IssueDate,book_issue.ReturnDate,book_issue.Status from book_issue inner join books on book_issue.BookID=books.BookID\r\n"
		 		+ "inner join user_details on book_issue.RequesterID=user_details.UserID \r\n"
		 		+ "where book_issue.RequesterID="+userID;
		 
		 ResultSet rs2 = stmt.executeQuery(strsql);
		 while(rs2.next()) {
			 HashMap bookObj = new HashMap();
			 bookObj.put("Book_ID", rs2.getString(1));
			 bookObj.put("Book_Name", rs2.getString(2));
			 bookObj.put("Requested_Date",rs2.getString(3));
			 bookObj.put("Issued_Date",rs2.getString(4));
			 bookObj.put("Return_Date",rs2.getString(5));
			 bookObj.put("Status",rs2.getString(6));
			 System.out.println(bookObj);
			 myRequests.add(bookObj);
		 }
		 
		 
		 
		 dbcon.close();
	 }catch(Exception e){System.out.println(e); 
	  return null;
	 }
	
	
	
	
	
	results.put("myrequests",myRequests);
	results.put("pendingrequests",pendingRequests);
	
	return results;
}


public HashMap issueBook(String userID,String bookID) {
	Connection dbcon = getDBConnection();
	
	HashMap results = new HashMap();
	
	Vector pendingRequests = new Vector();
	
	Vector myRequests = new Vector();
	 int f = 0;
	 try {
		 Statement stmt = dbcon.createStatement();
		 String strsql = "select UserID from books where BookID="+Integer.parseInt(bookID);
		 ResultSet rs1 = stmt.executeQuery(strsql);
		 while(rs1.next()) {
			 f = rs1.getInt(1);
		 }
		 
		 
		 strsql = "select BookID from book_issue where Status='issued' and BookID="+bookID;
		 ResultSet rs2 = stmt.executeQuery(strsql);
		 boolean check = true;
		 while(rs2.next()) {
			 
			 check=false;
		 }
		 if(check==true) {
			 strsql= "update book_issue set Status='issued',IssueDate =(select CURRENT_DATE()),ReturnDate =(select DATE_ADD((select CURRENT_DATE()),INTERVAL 15 DAY)) where BookID="+Integer.parseInt(bookID)+" and RequesterID="+Integer.parseInt(userID);
			 System.out.println(strsql);
			 stmt.executeUpdate(strsql);
			 
			
			 
			 
		 }
		 results = getDashboard(f);
		 if(check==false) {
			 results.put("error","Book Already Issued!");
		 }
		 dbcon.close();
		
	 }catch(Exception e) {System.out.println(e);
	 return null;
	 }
	 return results; 
		 
}
	
	 public Connection getDBConnection() {
		 Connection dbcon =null;
		try {
		 Class.forName("com.mysql.jdbc.Driver");  
		 dbcon = DriverManager.getConnection("jdbc:mysql://localhost:3306/bookpublish","root","Daliarani123#");
		/* Statement stmt=dbcon.createStatement();  
		 ResultSet rs=stmt.executeQuery("select * from emp");  
		 while(rs.next()) 
		 System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)); 
		 dbcon.close();*/
		 
		 }catch(Exception e){ System.out.println(e);}  
		return dbcon;
	 }
}
