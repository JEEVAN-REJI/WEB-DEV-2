package com.mutualbooks.app;

import java.util.*;

public class Wallet {
	private int userID;
	private int balance;
	
	public int getUserID() {
		return userID;
	}
	
	public int getBalance() {
		return balance;
	}
	
	
	public void setUserID(int iUserID) {
		userID= iUserID;
	}
	public void setBalance(int iBalance) {
		balance= iBalance;
	}
	
}
