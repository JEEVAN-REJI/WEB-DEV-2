package com.mutualbooks.app;

import java.sql.*;

public class UserManager {

	 public int doRegister(User newUser) {
		 Connection dbcon = getDBConnection();
		 try {
			 Statement stmt = dbcon.createStatement();
			 String strsql="select max(UserID) from user_cred";
			 ResultSet rs = stmt.executeQuery(strsql);
			 int id = 0;
			 while(rs.next()) {
				 id = rs.getInt(1);
				 System.out.println(id);
			 }
			 id++;
			 newUser.setUserID(id);
			 strsql = "insert into user_details values("+id+",'"+newUser.getDisplayName()+"','"+newUser.getEmail()+"','"+newUser.getPhoneNumber()+"','"+newUser.getAddress()+"')";
			 
			stmt.executeUpdate(strsql);
			 
			 
			 strsql ="insert into user_cred values("+id+",'"+newUser.getLoginID()+"','"+newUser.getPassword()+"')";
			 stmt.executeUpdate(strsql);
			 dbcon.close();
			 return id;
		 }catch(Exception e){System.out.println(e); 
		 return 0;
		 }
		
	}
	 
	 public User doLogin(String strLogin, String strPwd) {
		 Connection dbcon = getDBConnection();
		 boolean ret = false;
		 User obj=null;
		 try {
		 Statement stmt=dbcon.createStatement();  
		 String strsql="select Password,UserID from user_cred where LoginID='"+strLogin+"'";
		 System.out.println(strsql);
		 ResultSet rs=stmt.executeQuery(strsql); 
		 String pwd=null;
		 Integer userid = null;
		 while(rs.next()) {
			 pwd = rs.getString(1);
			 userid = rs.getInt(2);
		 System.out.println(pwd); 
		 }
		System.out.println(strPwd);
		 if(pwd.equals(strPwd)) {
			 System.out.println("Login successfull!");
			 strsql = "select DisplayName,IsAdmin from user_details where UserID="+userid;
			 rs = stmt.executeQuery(strsql);
			 String dispname=null;
			 String isadmin=null;
			 while(rs.next()) {
				 dispname = rs.getString(1);
				 isadmin = rs.getString(2);
			 }
			 obj = new User();
			 obj.setUserID(userid);
			 obj.setDisplayName(dispname);
			 obj.setIsAdmin(isadmin);
		 }
		 dbcon.close();
		 return obj;
		 }catch(Exception e) {System.out.println(e); 
		 return null;
		 }
	 }
	 
	 public boolean doPwdChange(int userID,String pwd) {
		 Connection dbcon = getDBConnection();
		 try {
			 Statement stmt = dbcon.createStatement();
			 String strsql="update user_cred set Password ='"+pwd+"' where UserID="+userID;
			 System.out.println(strsql);
			 stmt.executeUpdate(strsql);
			 dbcon.close();
			 return true;
		 }catch(Exception e){System.out.println(e); 
		 return false;
		 }
		 
	 }
	 
	 public Connection getDBConnection() {
		 Connection dbcon =null;
		try {
		 Class.forName("com.mysql.jdbc.Driver");  
		 dbcon = DriverManager.getConnection("jdbc:mysql://localhost:3306/bookpublish","root","Daliarani123#");
		/* Statement stmt=dbcon.createStatement();  
		 ResultSet rs=stmt.executeQuery("select * from emp");  
		 while(rs.next()) 
		 System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)); 
		 dbcon.close();*/
		 
		 }catch(Exception e){ System.out.println(e);}  
		return dbcon;
	 }
	
}

