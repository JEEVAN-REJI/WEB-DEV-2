package com.mutualbooks.app;

import java.util.*;

public class Book {

	private int bookID;
	private String title;
	private ArrayList<String> authors = new ArrayList<String>(4);
	private String publisher;
	private String edition;
	private String year;
	private int userID;

   public int getBookID() {
	   return bookID;
   }
   
   public String getTitle() {
	   return title;
   }
   
   public ArrayList<String> getAuthors() {
	   return authors;
   }
   
   public String getPublisher() {
	   return publisher;
   }
   
   public String getEdition() {
	   return edition;
   }
   
   public String getYear() {
	   return year;
   }
   
   public int getUserID() {
	   return userID;
   }
      
   // Setter functions
   
   public void setBookID(int iBookID) {
	    bookID= iBookID;
   }
   
   public void setTitle(String iTitle) {
	   title = iTitle;
   }
   
   public void setAuthors(String iAuth1, String iAuth2, String iAuth3, String iAuth4) {
	   authors.add(0, iAuth1);
	   authors.add(1, iAuth2);
	   authors.add(2, iAuth3);
	   authors.add(3, iAuth4);
   }
   
   public void setPublisher(String iPublisher) {
	   publisher=iPublisher;
   }
   
   public void setEdition(String iEdition) {
	   edition=iEdition;
   }
   
   public void setYear(String iYear) {
	   year=iYear;
   }
   
   public void setUserID(int iUserID) {
	   userID = iUserID;
   }
}
