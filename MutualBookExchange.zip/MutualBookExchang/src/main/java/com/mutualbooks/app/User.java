package com.mutualbooks.app;

public class User {

	private int userid;
	private String loginid;
	private String password;
	private String displayname;
	private String phonenumber;
	private String email;
	private String address;
	private String isadmin;
   public int getUserID() {
	   return userid;
   }
   
   public String getLoginID() {
	   return loginid;
   }
   
   public String getPassword() {
	   return password;
   }
   
   public String getDisplayName() {
	   return displayname;
   }
   
   public String getEmail() {
	   return email;
   }
   
   public String getAddress() {
	   return address;
   }
   
   public String getPhoneNumber() {
	   return phonenumber;
   }
   
   public String getIsAdmin() {
	   return isadmin;
   }
   
   // Setter functions
   
   public void setUserID(int iUserID) {
	    userid= iUserID;
   }
   
   public void setLoginID(String iLoginID) {
	   loginid = iLoginID;
   }
   
   public void setPassword(String iPwd) {
	   password = iPwd;
   }
   
   public void setDisplayName(String iName) {
	   displayname=iName;
   }
   
   public void setEmail(String iEmail) {
	   email=iEmail;
   }
   
   public void setAddress(String iAddress) {
	   address=iAddress;
   }
   
   public void setPhoneNumber(String iPhoneNumber) {
	   phonenumber=iPhoneNumber;
   }
   
   public void setIsAdmin(String iIsAdmin) {
	   isadmin = iIsAdmin;
   }
}
