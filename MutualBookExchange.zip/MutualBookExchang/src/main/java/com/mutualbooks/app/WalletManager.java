package com.mutualbooks.app;

import java.sql.*;
public class WalletManager {

	public int doWltRegister(Wallet newWallet) {
		Connection dbcon = getDBConnection();
		 try {
			 Statement stmt = dbcon.createStatement();
			 String strsql=null;
			 strsql = "insert into wallet values("+newWallet.getUserID()+","+newWallet.getBalance()+")";
			 
			stmt.executeUpdate(strsql);
			 dbcon.close();
			 return newWallet.getUserID();
		 }catch(Exception e){System.out.println(e); 
		 return 0;
		 }
	}
	
	public boolean requestRecharge(int iUserID,String ibalance) {
		Connection dbcon = getDBConnection();
		 try {
			 Statement stmt = dbcon.createStatement();
			 String strsql=null;
			 int bance = Integer.parseInt(ibalance);
			 strsql = "select Balance from wallet where UserID="+iUserID;
			 ResultSet rs = stmt.executeQuery(strsql);
			 int temp=0;
			 while(rs.next()) {
				 temp = rs.getInt(1);
			 }
			 bance = bance+temp;
			 strsql = "update wallet set Balance="+bance+" where UserID="+iUserID+";";
			 
			stmt.executeUpdate(strsql);
			 dbcon.close();
			 return true;
		 }catch(Exception e){System.out.println(e); 
		 return false;
		 }
	}
	
	 public Connection getDBConnection() {
		 Connection dbcon =null;
		try {
		 Class.forName("com.mysql.jdbc.Driver");  
		 dbcon = DriverManager.getConnection("jdbc:mysql://localhost:3306/bookpublish","root","Daliarani123#");
		/* Statement stmt=dbcon.createStatement();  
		 ResultSet rs=stmt.executeQuery("select * from emp");  
		 while(rs.next()) 
		 System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)); 
		 dbcon.close();*/
		 
		 }catch(Exception e){ System.out.println(e);}  
		return dbcon;
	 }
	
}
